## Plate-Scan ---------

## Detect car/vehicle Number plates easily